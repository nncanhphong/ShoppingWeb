﻿using Microsoft.AspNetCore.Mvc;

namespace SV21T1020581.Shop.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult ChangePassword()
        {
            return View();
        }
        public IActionResult UpdateInformation()
        {
            return View();
        }
    }
}
