﻿using Microsoft.AspNetCore.Mvc;

namespace SV21T1020581.Shop.Controllers
{
    public class ShoppingController : Controller
    {
        public IActionResult Cart()
        {
            return View();
        }
        public IActionResult Create()
        {
            return View();
        }

        public IActionResult Shopping()
        {
            return View();
        }

        public IActionResult ShoppingDetails()
        {
            return View();
        }
    }
}
