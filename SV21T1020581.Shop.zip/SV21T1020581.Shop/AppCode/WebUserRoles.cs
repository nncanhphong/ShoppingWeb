﻿namespace SV21T1020581.Shop
{
    public class WebUserRoles
    {
        public const string ADMINSTATOR = "admin";
        public const string EMPLOYEE = "employee";
    }
}
